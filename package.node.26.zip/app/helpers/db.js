module.exports = {
    User: require('../models/user.model'),
    Courses : require('../models/courses.model')
    
}